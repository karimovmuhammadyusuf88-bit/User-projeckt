import UserCard from "./UserCard";

function UserMap({
  users,
  handleEdit,
  handleDelete,
}) {
  return (
    <section className="py-10 bg-green-600">
      <div className="container mx-auto px-6">

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">

          {users.length > 0 ? (
            users.map((user) => (
              <UserCard
                key={user.id}
                user={user}
                handleEdit={handleEdit}
                handleDelete={handleDelete}
              />
            ))
          ) : (
            <div className="col-span-full text-center text-white text-2xl font-semibold">
              User topilmadi 😔
            </div>
          )}

        </div>

      </div>
    </section>
  );
}

export default UserMap;