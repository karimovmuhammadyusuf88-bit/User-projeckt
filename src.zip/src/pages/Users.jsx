import { useState, useRef } from "react";

import { users as userData } from "../data/users";

import Search from "../components/Search";
import UserMap from "../components/UserMap";
function Users() {
  const [users, setUsers] = useState(userData);
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);

  // useRef
  const firstNameRef = useRef();
  const lastNameRef = useRef();
  const jobRef = useRef();
  const cityRef = useRef();
  const ageRef = useRef();

  // Create
  const handleCreate = (e) => {
    e.preventDefault();
    console.log(users);
    console.log("Create ishladi");
    const newUser = {
      id: Date.now(),
      firstName: firstNameRef.current.value,
      lastName: lastNameRef.current.value,
      age: ageRef.current.value,
      job: jobRef.current.value,
      city: cityRef.current.value,
      image: `https://randomuser.me/api/portraits/men/${Math.floor(
        Math.random() * 90 + 1
      )}.jpg`,
    };

    setUsers([...users, newUser]);

    firstNameRef.current.value = "";
    lastNameRef.current.value = "";
    ageRef.current.value = "";
    jobRef.current.value = "";
    cityRef.current.value = "";
    setShowForm(false);
  };

  // Search
  const filteredUsers = users.filter((user) =>
    `${user.firstName} ${user.lastName} ${user.job} ${user.city}`
      .toLowerCase()
      .includes(search.toLowerCase())
  );

  // Delete
  const handleDelete = (id) => {
    const confirmDelete = window.confirm(
      "Rostdan ham o'chirmoqchimisiz?"
    );

    if (confirmDelete) {
      setUsers(users.filter((user) => user.id !== id));
    }
  };

  // Edit
  const handleEdit = (user) => {
    const firstName = prompt("First Name", user.firstName);
    const lastName = prompt("Last Name", user.lastName);
    const job = prompt("Job", user.job);
    const city = prompt("City", user.city);
    const age = prompt("Age", user.age);

    if (firstName && lastName && job && city && age) {
      setUsers(
        users.map((item) =>
          item.id === user.id
            ? {
              ...item,
              firstName,
              lastName,
              job,
              city,
              age,
            }
            : item
        )
      );
    }
  };

  return (
    <>
      <button
        onClick={() => setShowForm(true)}
        className="bg-blue-600 text-white px-5 py-2 rounded mb-5"
      >
        Create
      </button>

      {showForm && (
        <form onSubmit={handleCreate} className="flex flex-wrap gap-3 mb-5">
          <input
            ref={firstNameRef}
            type="text"
            placeholder="First Name"
            className="border p-2 rounded"
          />

          <input
            ref={lastNameRef}
            type="text"
            placeholder="Last Name"
            className="border p-2 rounded"
          />

          <input
            ref={jobRef}
            type="text"
            placeholder="Job"
            className="border p-2 rounded"
          />

          <input
            ref={cityRef}
            type="text"
            placeholder="City"
            className="border p-2 rounded"
          />

          <input
            ref={ageRef}
            type="number"
            placeholder="Age"
            className="border p-2 rounded"
          />

          <button
            type="submit"
            className="bg-green-600 text-white px-5 py-2 rounded"
          >
            Save
          </button>
        </form>
      )}

      <Search
        search={search}
        setSearch={setSearch}
        placeholder="Search users..."
      />

      <UserMap
        users={filteredUsers}
        handleEdit={handleEdit}
        handleDelete={handleDelete}
      />
    </>
  );
}

export default Users;